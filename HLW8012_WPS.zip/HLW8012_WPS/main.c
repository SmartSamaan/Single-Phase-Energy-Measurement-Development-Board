/* MAIN.C file
 * 
 * Copyright (c) 2002-2005 STMicroelectronics
 */ 
#include "stm8s.h"
//#include "stm8s_flash.h"
#include "OLED_f103f3.h"
#include "HLW8012.h"
#include "IWDG_Timer.h"
#include "Flash_EEPROM.h"

float V_Array[10], I_Array[10], P_Array[10];
uint8_t AvgIdx = 0;
bool headerFlag = TRUE, ArrayFull = FALSE;

void MeasureData(void)
{
  IWDG_Refresh();
  GPIOC->ODR &= ~0x40;
  delay_ms(500);
  IWDG_Refresh();
  D_Volt = 1273.14*VI_Freq*VREF*512/(2*FOSC);        // Voltage
  V_Array[AvgIdx] = D_Volt > 20? D_Volt : 0;
  VI_Freq = 0;
  GPIOC->ODR |= 0x40;
  delay_ms(500);
  IWDG_Refresh();
  I_Array[AvgIdx] = 238.16*VI_Freq*VREF*512/(24*FOSC);       // Current
  VI_Freq = 0;
  P_Array[AvgIdx] = 872607.91*P_Freq*VREF*VREF*128/(48*FOSC);   // Power
  if(ArrayFull)
  {
    D_Volt = V_Array[0]+V_Array[1]+V_Array[2]+V_Array[3]+V_Array[4]+V_Array[5]+V_Array[6]+V_Array[7]+V_Array[8]+V_Array[9];
    D_Volt /= 10;
    D_Curr = I_Array[0]+I_Array[1]+I_Array[2]+I_Array[3]+I_Array[4]+I_Array[5]+I_Array[6]+I_Array[7]+I_Array[8]+I_Array[9];
    D_Curr /= 10;
    D_Power = P_Array[0]+P_Array[1]+P_Array[2]+P_Array[3]+P_Array[4]+P_Array[5]+P_Array[6]+P_Array[7]+P_Array[8]+P_Array[9];
    D_Power /= 10;
  }
  else
  {
    D_Volt = V_Array[AvgIdx];
    D_Curr = I_Array[AvgIdx];
    D_Power = P_Array[AvgIdx];
    for(uint8_t i = 0; i < 10; i++)
    {
      V_Array[i] = D_Volt;
      I_Array[i] = D_Curr;
      P_Array[i] = D_Power;
    }
  }
  IWDG_Refresh();
  if(PowerFlag == 0)
  {
    for(uint8_t i = 0; i < 10; i++)
    {
      V_Array[i] = 0;
      I_Array[i] = 0;
      P_Array[i] = 0;
    }
    P_Freq = 0;
    D_Curr = 0;
    D_Power = 0;
    D_ApPower = 0;
    D_PFactor = 0;
    ArrayFull = FALSE;
  }
  else
  {
    AvgIdx++;
    if(AvgIdx >= 10)
    {
      ArrayFull = TRUE;
      AvgIdx = 0;
    }
    D_ApPower = D_Volt*D_Curr;
    if(D_ApPower == 0)
      D_PFactor = 0;
    else
      D_PFactor = D_Power/D_ApPower;
    if(D_PFactor > 1)
      D_PFactor = 1;
    PowerFlag = 0;
  }
  D_Energy = Energy;
}
void Display_Data(uint8_t WinNumber)
{
  if(WinNumber == 0)
  {
    if(headerFlag)
    {
      OLED_print_string(24,0, "DISPLAY 1");
      OLED_print_string(0,2, "VOLT:");
      OLED_print_string(0,4, "AMPS:");
      OLED_print_string(0,6, "WATT: ");
    }
    OLED_print_float(40, 2, D_Volt, 1);
    OLED_print_float(40, 4, D_Curr, 2);
    OLED_print_float(40, 6, D_Power, 2);
    headerFlag = FALSE;
  }
  if(WinNumber == 1)
  {
    if(headerFlag)
    {
      OLED_print_string(24,0, "DISPLAY 2");
      OLED_print_string(0,2, "VA  :");
      OLED_print_string(0,4, "PF  :");
      OLED_print_string(0,6, "KWH : ");
    }
    OLED_print_float(40, 2, D_ApPower, 2);
    OLED_print_float(40, 4, D_PFactor, 3);
    OLED_print_float(40, 6, D_Energy, 3);
    headerFlag = FALSE;
  }
}
int main(void)
{
  uint8_t WinNumber = 0;
  CLK->ICKR |= CLK_ICKR_HSIEN;
  CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_HSIDIV);
  CLK->CKDIVR |= (uint8_t)((uint8_t)CLK_PRESCALER_HSIDIV1 & (uint8_t)CLK_CKDIVR_HSIDIV);
  CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_CPUDIV);
  CLK->CKDIVR |= (uint8_t)((uint8_t)CLK_PRESCALER_CPUDIV1 & (uint8_t)CLK_CKDIVR_CPUDIV);
  /*if (RST_GetFlagStatus(RST_FLAG_IWDGF) != RESET)
  {
    // Clear IWDGF Flag 
    RST_ClearFlag(RST_FLAG_IWDGF);
  }*/
  Init_HLW8012();
  IWDG_Init((uint8_t)IWDG_MAX_TIME);
  FLASH_EEPROM_Init();
  OLED_init();
  IWDG_Refresh();
  OLED_draw_logo(15,11,105,13,(uint8_t*)logo);
  IWDG_Refresh();
  delay_ms(800);
  IWDG_Refresh();
  delay_ms(800);
  IWDG_Refresh();
  delay_ms(800);
  IWDG_Refresh();
  delay_ms(800);
  IWDG_Refresh();
  delay_ms(800);
  MeasureTIMEOUT = 0;
  IWDG_Refresh();
  OLED_clear_screen();
  IWDG_Refresh();
  OLED_print_string(24,3,"LOADING...");
  //delay_ms(200);
  IWDG_Refresh();
  for(uint8_t i = 0; i < 10; i++)
  {
    MeasureData();
    IWDG_Refresh();
  }
  DisplayTIMEOUT = 0;
  while (1)
  {
    IWDG_Refresh();
    if(MeasureTIMEOUT > 800)
    {
      MeasureTIMEOUT = 0;
      MeasureData();
      IWDG_Refresh();
      Display_Data(WinNumber);
      FLASH_ProgramWord(0x4000, (uint32_t)(Energy*10000));
    }
    if(DisplayTIMEOUT > 3000)
    {
      DisplayTIMEOUT = 0;
      headerFlag = TRUE;
      IWDG_Refresh();
      WinNumber++;
    }
    if(WinNumber > 1)
      WinNumber = 0;
    IWDG_Refresh();
  }
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* Infinite loop */
  while (1)
  {
  }
}
#endif
