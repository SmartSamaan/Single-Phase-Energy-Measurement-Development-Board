#include "oled_data.h"
#include "OLED_F103F3.h"

void Display_Voltage(void)
{
  uint16_t i;
  uint8_t j, xpos = 0, ypos = 0;
  
  /*OLED_gotoxy(xpos+0, ypos+0);
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
  for(i = 0; i < 416; i++)
  {
    buffer[i] = FLASH_ReadByte(0x4000+i);
  }
  for(i=0; i < 416; i++)
      OLED_write(buffer[i], DAT);
  /*for(i = 0; i < 1; i+=8)
  {
    for(j = i; j < (i+8); j++)
      OLED_write(buffer[j], DAT);
  }*/
  /*
  OLED_gotoxy(xpos+8, ypos);
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
  for(i = 0; i < 8; i++)
  {
    OLED_write(FLASH_ReadByte(0x4000+16*21+i), DAT);
  }
  OLED_gotoxy(xpos+8, ypos+1);
  for(i = 8; i < 16; i++)
  {
    OLED_write(FLASH_ReadByte(0x4000+16*21+i), DAT);
  }
  //
  OLED_gotoxy(xpos+16, ypos);
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
  for(i = 0; i < 8; i++)
  {
    OLED_write(FLASH_ReadByte(0x4000+16*19+i), DAT);
  }
  OLED_gotoxy(xpos+16, ypos+1);
  for(i = 8; i < 16; i++)
  {
    OLED_write(FLASH_ReadByte(0x4000+16*19+i), DAT);
  }
  //
  OLED_gotoxy(xpos+24, ypos);
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
  for(i = 0; i < 8; i++)
  {
    OLED_write(FLASH_ReadByte(0x4000+16*24+i), DAT);
  }
  OLED_gotoxy(xpos+24, ypos+1);
  for(i = 8; i < 16; i++)
  {
    OLED_write(FLASH_ReadByte(0x4000+16*24+i), DAT);
  }*/
}