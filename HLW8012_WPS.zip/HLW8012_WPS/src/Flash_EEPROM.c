#include "Flash_EEPROM.h"

void FLASH_EEPROM_Init(void)
{
 /* Define flash programming Time*/
  //FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);

  //FLASH_Unlock(FLASH_MEMTYPE_PROG);
  /* Wait until Flash Program area unlocked flag is set*/
  //while (FLASH_GetFlagStatus(FLASH_FLAG_PUL) == RESET)
  //{}
  /*Define FLASH programming time*/
  FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);
  /* Unlock flash data eeprom memory */
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
  /* Wait until Data EEPROM area unlocked flag is set*/
  while (FLASH_GetFlagStatus(FLASH_FLAG_DUL) == RESET)
  {}
}