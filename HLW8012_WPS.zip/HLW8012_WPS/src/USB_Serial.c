/**
  ******************************************************************************
  * @file    USB_Serial.c
  * @author  Sajjad Ahmed
  * @version V1.0
  * @date    02-June-2023
  * @brief   This file contains all functions for the USB Serial Communication
  ******************************************************************************
  */
#include "usb_serial.h"
#include "stm8s_it.h"


void USB_Serial_Init(void)
{
	UART1_DeInit();
	// Enable UART Clock
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_UART1, ENABLE);
	UART1_Init(9600, 
					    UART1_WORDLENGTH_8D, 
						UART1_STOPBITS_1, 
						UART1_PARITY_NO, 
						UART1_SYNCMODE_CLOCK_DISABLE, 
						UART1_MODE_TXRX_ENABLE);
	UART1_ITConfig(UART1_IT_RXNE_OR, ENABLE);	// Enable RX Interrupt
	enableInterrupts();
}
void Process_Data(void)
{
	
}