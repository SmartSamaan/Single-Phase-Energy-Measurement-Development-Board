#include "HLW8012.h"
#include "stm8s_it.h"

uint16_t DisplayTIMEOUT = 0, MeasureTIMEOUT = 0;
double D_Volt, D_Curr, D_Power, D_ApPower, D_PFactor, D_Energy;
double Energy = 0.0;
const float FOSC = 3579000, VREF = 2.43;
uint8_t PowerFlag = 0;
float ApPower, PFactor;
uint32_t countVI = 0, countP = 0;
double VI_Freq = 0, P_Freq = 0;
void Init_TIM4_Base(void)
{
  //TIM4_TimeBaseInit(TIM4_PRESCALER_128, 249);   // Timebase of 2ms
  TIM4->PSCR = (uint8_t)(TIM4_PRESCALER_128);
  /* Set the Autoreload value */
  TIM4->ARR = 249;
  TIM4->SR1 = (uint8_t)(~TIM4_FLAG_UPDATE);
  /* Enable update interrupt */
  //TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
  TIM4->IER |= (uint8_t)TIM4_IT_UPDATE;
  /* Enable TIM4 */
  //TIM4_Cmd(ENABLE);
  TIM4->CR1 |= TIM4_CR1_CEN;
}
void Init_HLW8012(void)
{
  uint32_t tmpE;
  tmpE = (uint32_t)FLASH_ReadByte(0x4000)<<24;
  tmpE |= (uint32_t)FLASH_ReadByte(0x4001)<<16;
  tmpE |= (uint32_t)FLASH_ReadByte(0x4002)<<8;
  tmpE |= (uint32_t)FLASH_ReadByte(0x4003);
  Energy = (double)(tmpE/10000.0);
  //GPIO_Init(GPIOC, GPIO_PIN_7, GPIO_MODE_IN_FL_IT);     // Voltage/Current
  GPIOC->DDR &= (uint8_t)(~(GPIO_PIN_7));
  GPIOC->CR1 &= (uint8_t)(~(GPIO_PIN_7));
  GPIOC->CR2 |= (uint8_t)GPIO_PIN_7;
  //GPIO_Init(GPIOD, GPIO_PIN_2, GPIO_MODE_IN_FL_IT);     // Power
  GPIOD->DDR &= (uint8_t)(~(GPIO_PIN_2));
  GPIOD->CR1 &= (uint8_t)(~(GPIO_PIN_2));
  GPIOD->CR2 |= (uint8_t)GPIO_PIN_2;
  //EXTI_DeInit();
  //EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOC, EXTI_SENSITIVITY_FALL_ONLY);
  EXTI->CR1 &= (uint8_t)(~EXTI_CR1_PCIS);
  EXTI->CR1 |= (uint8_t)((uint8_t)(EXTI_SENSITIVITY_FALL_ONLY) << 4);
  //EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOD, EXTI_SENSITIVITY_FALL_ONLY);
  EXTI->CR1 &= (uint8_t)(~EXTI_CR1_PDIS);
  EXTI->CR1 |= (uint8_t)((uint8_t)(EXTI_SENSITIVITY_FALL_ONLY) << 6);
  //ITC_SetSoftwarePriority(ITC_IRQ_PORTC, ITC_PRIORITYLEVEL_3);
  //ITC_SetSoftwarePriority(ITC_IRQ_PORTD, ITC_PRIORITYLEVEL_2);
  Init_TIM4_Base();
  // Run Timer 1 on 1.6 MHz
  TIM1->ARRH = 0xFF;
  TIM1->ARRL = 0xFF;
  TIM1->PSCRL = 9;
  TIM1->CR1 = 0x01;
  //TIM1_Cmd(ENABLE);
  TIM1->IER = TIM1_IT_UPDATE;     // 0x04 | 0x01 (TIM1_IT_CC2|TIM1_IT_UPDATE)
  /*Run Timer 2 on 2MHz*/
  TIM2->ARRH = 0xFF;
  TIM2->ARRL = 0xFF;
  TIM2->PSCR = TIM2_PRESCALER_8;
  TIM2->CR1 = 0x01;
  //TIM1_Cmd(ENABLE);
  TIM2->IER = TIM2_IT_UPDATE;     // 0x04 | 0x01 (TIM1_IT_CC2|TIM1_IT_UPDATE)
  //GPIO_Init(HLW8012_PORT, SEL_Pin, GPIO_MODE_OUT_PP_LOW_FAST);
  GPIOC->DDR |= (uint8_t)SEL_Pin;
  GPIOC->CR1 |= (uint8_t)SEL_Pin;
  GPIOC->CR2 |= (uint8_t)SEL_Pin;
  GPIOC->ODR &= (uint8_t)(~(SEL_Pin));
  enableInterrupts();
}
INTERRUPT_HANDLER(TIM4_UPD_OVF_IRQHandler, 23)
{
  TIM4->SR1 = ~TIM4_IT_UPDATE;
  double P = D_Power/1000000.0;
  Energy += P/1800.0;       // Energy += Power*1/3600*1/1000*1/1000 in kWh
  DisplayTIMEOUT++;
  MeasureTIMEOUT++;
}
INTERRUPT_HANDLER(TIM1_UPD_OVF_TRG_BRK_IRQHandler, 11)
{
  TIM1->SR1 = ~TIM1_FLAG_UPDATE;
  countVI++;
}
INTERRUPT_HANDLER(TIM2_UPD_OVF_BRK_IRQHandler, 13)
{
  TIM2->SR1 = ~TIM2_FLAG_UPDATE;
  countP++;
}
INTERRUPT_HANDLER(EXTI_PORTC_IRQHandler, 5)     // Voltage/Current interrupt
{
  TIM1->CR1 &= ~0x01;
  uint16_t T1_CNTH, T1_CNTL;
  uint32_t counterVal1 = countVI << 16;
  T1_CNTH = TIM1->CNTRH;
  T1_CNTL = TIM1->CNTRL;
  counterVal1 += (T1_CNTH << 8)|T1_CNTL;
  VI_Freq = 1600000.0/(double)(counterVal1);
  countVI = 0;
  TIM1->CNTRH = 0;
  TIM1->CNTRL = 0;
  TIM1->CR1 |= 0x01;
}
INTERRUPT_HANDLER(EXTI_PORTD_IRQHandler, 6)     // Power Interrupt
{
  TIM2->CR1 &= ~0x01;
  uint16_t T2_CNTH, T2_CNTL;
  uint32_t counterVal2 = countP << 16;
  T2_CNTH = TIM2->CNTRH;
  T2_CNTL = TIM2->CNTRL;
  counterVal2 += (T2_CNTH << 8)|T2_CNTL;
  P_Freq = 2000000.0/(double)(counterVal2);
  PowerFlag = 1;
  countP = 0;
  TIM2->CNTRH = 0;
  TIM2->CNTRL = 0;
  TIM2->CR1 |= 0x01;
}