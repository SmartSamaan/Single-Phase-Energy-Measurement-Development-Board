/**
  ******************************************************************************
  * @file    USB_Serial.h
  * @author  Sajjad Ahmed
  * @version V1.0
  * @date    02-June-2023
  * @brief   This file contains all functions prototype and macros for the USB Serial Communication
  ******************************************************************************
  */
#include "stm8s_uart1.h"

	
void USB_Serial_Init(void);