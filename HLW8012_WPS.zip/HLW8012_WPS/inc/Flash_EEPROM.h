#include "stm8s_flash.h"

#define BLOCK_OPERATION    0
void FLASH_EEPROM_Init(void);