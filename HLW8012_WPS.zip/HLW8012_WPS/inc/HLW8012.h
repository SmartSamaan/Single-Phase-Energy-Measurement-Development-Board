#include "stm8s.h"

#define HLW8012_PORT    GPIOC
#define SEL_Pin         GPIO_PIN_6      // Inverted because of BJT Q1

extern const float FOSC, VREF;
extern uint8_t PowerFlag;
extern double D_Volt, D_Curr, D_Power, D_ApPower, D_PFactor, D_Energy;
extern uint16_t DisplayTIMEOUT, MeasureTIMEOUT;
extern double VI_Freq, P_Freq;
extern double Energy;


void Init_TIM1_IC(void);
void Init_TIM2_IC(void);
void Init_HLW8012(void);
