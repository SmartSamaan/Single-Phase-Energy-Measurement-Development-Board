#include "stm8s_iwdg.h"
#define IWDG_MAX_TIME   0xFF

void IWDG_Init(uint8_t value);
void IWDG_Refresh(void);